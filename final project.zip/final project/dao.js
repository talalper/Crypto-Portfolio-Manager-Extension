/**
 * DAO (Data Access Object) for managing user's cryptocurrency holdings using localStorage.
 *
 * Provides methods to load, save, update, and compute holdings along with timestamps
 * for tracking when each currency was last modified.
 */
const dao = {
    /**
     * Initializes the localStorage keys if they do not exist.
     * Creates empty structures for holdings and timestamps.
     */
    initialize: function () {
        if (!localStorage.getItem("cryptoHoldings")) {
            this.saveData({});
            localStorage.setItem("cryptoTimestamps", JSON.stringify({}));
        }
    },

    /**
     * Loads cryptocurrency holdings from localStorage (under the "cryptoHoldings" key)
     * and parses the data into an object.
     * URL - https://www.triple-a.io/cryptocurrency-ownership-data and parses it into an object.
     * The function returns an object -  a map of symbols to their respective amounts.
     */
    loadData: function () {
        const data = localStorage.getItem("cryptoHoldings");
        // If data is found, parse it; otherwise, return an empty object
        if (data) {
            return JSON.parse(data);
        }
        else{
            return{}
        }
    },

    /**
     * Saves the user's cryptocurrency holdings to localStorage under the key "cryptoHoldings".
     * 'data' - an object mapping currency symbols (e.g., "BTC", "ETH") to amounts.
     */
    saveData: function(data){
        localStorage.setItem("cryptoHoldings", JSON.stringify(data));
    },

    /**
     * Adds the specified amount to the given cryptocurrency symbol.
     * 'symbol' - The cryptocurrency symbol to add.
     * 'amount' - The amount to add.
     */
    add: function (symbol, amount) {
        // Load current holdings from localStorage
        const data = this.loadData();
        // If the currency doesn't exist yet, initialize it with zero
        if (!data[symbol]) {
            data[symbol] = 0;
        }

        // Add the specified amount to the existing balance
        data[symbol] += amount;
        // Save the updated holdings back to localStorage.
        this.saveData(data);
        // Record the current timestamp for this currency
        this.setTimestamp(symbol)
    },

    /**
     * Removes the specified amount from the given cryptocurrency symbol.
     * 'symbol' - The cryptocurrency symbol to remove from.
     * 'amount' - The amount to subtract.
     */
    remove: function (symbol, amount) {
        // Load current holdings from localStorage
        const data = this.loadData();
        // If the currency doesn't exist yet, initialize it with zero
        if(!data[symbol]) {
            // If it is a new coin - we start a new one with '0'.
            data[symbol] = 0;
        }
        // Subtract the specified amount from the balance
        data[symbol] -= amount;
        // If the balance is zero or negative, remove the currency from holdings
        if (data[symbol] <= 0) {
            // Clean up empty or negative balances.
            delete data[symbol];
        }
        // Save the updated holdings back to localStorage
        this.saveData(data);
        // Record the current timestamp for this currency
        this.setTimestamp(symbol)
    },

    /**
     * Returns the current holdings as an object from localStorage.
     */
    getHoldings: function () {
        return this.loadData();
    },

    /**
     * Calculates the total value of all holdings in USD.
     * 'currency' - The target currency (must be "USD").
     * Returns Promise - The total value in USD.
     */
    total: async function (currency) {
        if (currency !== "USD") {
            // Only USD is supported for total portfolio calculation
            console.warn("Only USD is supported for total calculation.");
            return 0;
        }
        // Load all user's holdings from localStorage
        const data = this.loadData();
        let total = 0;

        for (const symbol in data) {
            // Get the amount held for this currency
            const amount = data[symbol];
            // Fetch the current USD exchange rate
            const rate = await service.getRate(symbol);
            // Add the value in USD to the running total
            total += amount * rate;
        }
        // Return the total portfolio value in USD
        return total;
    },

    /* The function updates the last modified timestamp for a specific symbol.*/
    setTimestamp: function (symbol){
        // Load existing timestamps from localStorage (or initialize an empty object)
        const timestamps = JSON.parse(localStorage.getItem("cryptoTimestamps")) || {};
        // Set the current timestamp for the given symbol in ISO format
        timestamps[symbol] = new Date().toISOString();
        // Save the updated timestamps object back to localStorage
        localStorage.setItem("cryptoTimestamps", JSON.stringify(timestamps));
    },

    /*
    This function retrieves the last modified timestamp for a specific currency symbol.
     */
    getTimestamps: function (symbol) {
        // Load the saved timestamps from localStorage, or use an empty object if not found
        const timestamps = JSON.parse(localStorage.getItem("cryptoTimestamps")) || {};
        // Return the timestamp for the requested symbol, or null if it doesn't exist
        return timestamps[symbol] || null;
    }
};
