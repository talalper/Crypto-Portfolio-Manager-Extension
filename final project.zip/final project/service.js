/**
 * The `service` object is responsible for communicating with the
 * CEX.IO API to retrieve real-time exchange rates for cryptocurrencies.
 */

const service = {
    /**
     * Retrieves the latest exchange rate in USD for a given cryptocurrency symbol.
     *
     * This function sends a request to the CEX.IO API and parses the response to extract
     * the last known price in USD. If the response is invalid or an error occurs,
     * the function returns 0.
     * Else the function returns a promise object that present the current exchange rate in USD.
     *
     */
    getRate: async function (symbol) {
// Using try in order to get errors
        try {
            // Construct the API URL for the given symbol
            const url = `https://cex.io/api/last_price/${symbol}/USD`;
            // Send the HTTP request to the API
            const response = await fetch(url);
            //  Parse the response JSON
            const data = await response.json();
            // Validate and return the rate
            if (!data || !data.lprice || isNaN(data.lprice)) {
                return 0;
            }
            return parseFloat(data.lprice);
        }

        catch (error) {
            // Log and handle any error that occurs during fetch
            console.error(`Failed to fetch rate for ${symbol}:`, error);
            return 0;
        }
    }
};

