let myChartInstance = null;
// The list of the currency symbols that the user can select from
const SUPPORTED_CURRENCIES = ["BTC", "ETH", "XRP", "LTC", "BCH", "ADA", "DOGE", "SOL", "DOT", "MATIC", "BNB", "TRX", "EOS", "XLM"];

/**
 * Initialization function that runs after all DOM content is fully loaded.
 * - Initializes storage.
 * - Displays the table and total amount.
 * - Sets up event listeners.
 */
document.addEventListener("DOMContentLoaded", () => {
    dao.initialize();
    showTable();
    refreshUI();
    hideError();
    populateCurrencyDropdown();

    // Register click events for all action buttons
    document.getElementById("btnAdd").addEventListener("click", addCurrency);
    document.getElementById("btnRemove").addEventListener("click", removeCurrency);
    document.getElementById("btnTable").addEventListener("click", showTable);
    document.getElementById("btnChart").addEventListener("click", showChart);
    document.getElementById("btnStatus").addEventListener("click", showStatus);

    const closeErrorButton = document.getElementById("closeErrorBtn");
    // Adds click event listener to hide error messages when 'Close' is clicked
    if (closeErrorButton) {
        closeErrorButton.addEventListener("click", hideError);
    }

});

/**
 * Populates the currency selection dropdown with supported currency symbols.
 */
function populateCurrencyDropdown() {
    const selectElement = document.getElementById("currencySymbolSelect");
    // Clear existing options, in case it's called multiple times
    selectElement.innerHTML = '<option value="">Choose a currency</option>';
    SUPPORTED_CURRENCIES.forEach(symbol => {
        const option = document.createElement("option");
        option.value = symbol;
        option.textContent = symbol;
        selectElement.appendChild(option);
    });
}


/**
 * Asynchronously calculates and updates the total portfolio value in USD.
 * Retrieves data from the DAO and updates the corresponding DOM element.
 * @async
 * @returns {Promise<void>}
 */
async function updateTotal() {
    // Retrieves the total value in USD from the DAO
    const total = await dao.total("USD");
    // Updates the DOM element with the formatted total value
    document.getElementById("totalValue").innerText = total.toFixed(2);
}

/**
 * Displays an error message in a Bootstrap alert component.
 * @param {string} message - The error message to display.
 */
function showError(message) {
    // Get the span or div where the error message text should be inserted
    const errorText = document.getElementById("errorText");

    // Get the alert container element
    const errorBox = document.getElementById("errorMessage");

    // Update the text
    errorText.textContent = message;

    // Make the alert box visible by removing the "d-none" class
    errorBox.classList.remove("d-none");

    // Ensure the alert box is displayed as a flex container
    errorBox.classList.add("d-flex");

    // Update accessibility attribute to indicate the alert is now visible
    errorBox.setAttribute('aria-hidden', 'false');
}

// Function that hide the error message
function hideError() {
    const errorBox = document.getElementById("errorMessage");
    const closeButton = document.getElementById("closeErrorBtn");

    // Removes focus from the close button if it's currently focused
    if (closeButton && closeButton === document.activeElement) {
        closeButton.blur();
    }

    // Hide the alert box by removing the 'show' class
    errorBox.classList.add("d-none");
    errorBox.classList.remove("d-flex");
    errorBox.setAttribute('aria-hidden', 'true');
}

/**
 * Handles user input to add a new currency to the portfolio.
 * Validates input, fetches exchange rates, updates DAO, and refreshes UI.
 * @async
 * @returns {Promise<void>}
 */
async function addCurrency() {
    // Get the raw input from the "symbol" field
    // Convert to uppercase and cut the spaces for consistency and compatibility
    const manualInput = document.getElementById("currencySymbolManualInput").value.trim().toUpperCase();
    // Get the chosen symbol from the dropdown
    const selectValue = document.getElementById("currencySymbolSelect").value;
    // Get the amount from the input and convert it to a float
    const amount = parseFloat(document.getElementById("amount").value);
    showLoading();

    // If the user typed a symbol in the manualInput - we will use that
    let symbol;
    if (manualInput) {
        symbol = manualInput;
    }
    // If the user chose a symbol from the dropdown
    else if (selectValue) {
        symbol = selectValue;
    }
    // If the user did not choose or typed anything
    else {
        console.log("Validation failed: No currency symbol provided.");
        showError("Select a currency from the list or manually type the currency symbol");
        hideLoading();
        return;
    }
    // Check if symbol is missing, amount is not a number, or amount is non-positive
    if (isNaN(amount) || amount <= 0){
        console.log("Validation failed: invalid amount.");
        showError("Please enter a positive amount.");
        return;}

    // If rate is invalid or currency not found, show error and stop processing
    console.log(`Attempting to get rate for: ${symbol}`);
    const rate = await service.getRate(symbol);
    console.log(`Rate received for ${symbol}:`, rate);

    // Checking if the currency does not found or rate is invalid
    if (isNaN(rate) || rate === 0) {
        hideLoading();
        console.log(`Currency "${symbol}" does not exist or rate is invalid.`);
        showError(`ERROR: currency "${symbol}" not found.`);
        return;
    }

    // Add the currency and amount to the user's holdings (stored via DAO)
    dao.add(symbol, amount);

    // Clear input fields after successful addition
    document.getElementById("currencySymbolSelect").value = "";
    document.getElementById("currencySymbolManualInput").value = "";
    document.getElementById("amount").value = "";

    // Hide any previous error message
    hideError()

    // Refresh the entire UI to reflect the new data
    await refreshUI();

    // Hide the loading spinner
    hideLoading();
    // After showing the loading spinner the user will receive  a success message
    showSuccess(`Currency "${symbol}" added successfully!`);

}

/**
 * Displays a success message to the user.
 * @param {string} message - The success message to display.
 */
function showSuccess(message) {
    // Retrieves the DOM element for the success message container
    const successBox = document.getElementById("successMessage");
    // Retrieves the DOM element for the success message text
    const successText = document.getElementById("successText");

    // Update the text content
    successText.textContent = message;

    // Remove the 'd-none' class so the message is no longer hidden
    successBox.classList.remove("d-none");

    // Add the 'd-block' class to make the message visible
    successBox.classList.add("d-block");

    // After 3 seconds, hide the message again
    setTimeout(() => {
        successBox.classList.remove("d-block");
        successBox.classList.add("d-none");
    }, 3000);
}



/**
 * Handles user input to remove a specified amount of a currency from the portfolio.
 * Validates input, updates DAO, refreshes UI, and displays feedback messages.
 * @async
 * @returns {Promise<void>}
 */
async function removeCurrency() {
    // Get the raw input from the "symbol" field
    // Convert to uppercase and cut the spaces for consistency and compatibility
    const manualInput = document.getElementById("currencySymbolManualInput").value.trim().toUpperCase();
    // Get the chosen symbol from the dropdown
    const selectValue = document.getElementById("currencySymbolSelect").value;

    // Parse the input amount as a floating point number
    const amount = parseFloat(document.getElementById("amount").value);

    // If the user typed a symbol in the manualInput - we will use that
    let symbol;
    if (manualInput) {
        symbol = manualInput;
    }
    // If the user chose a symbol from the dropdown
    else if (selectValue) {
        symbol = selectValue;
    }
    // If the user did not choose or typed anything
    else {
        console.log("Validation failed: No currency symbol provided.");
        showError("Select a currency from the list or manually type the currency symbol");
        hideLoading();
        return;
    }

    // Validate inputs: must a positive numeric amount
    if (isNaN(amount) || amount <= 0){
        console.log("Validation failed: Invalid amount for removal");
        showError("Please enter a positive amount to remove");
        hideLoading();
        return;
    }

    // Show loading spinner during processing
    showLoading();

    // Retrieve the user's current holdings
    const holdings = dao.getHoldings();

    // Check if the user actually owns any of the specified currency
    if (!holdings[symbol] || holdings[symbol] === 0) {
        hideLoading();
        console.log(`Attempted to remove non-existent currency: ${symbol}`);
        showError(`ERROR: You do not hold any ${symbol} to remove`);
        return;
    }

    // Proceed with removing the specified amount of the currency
    dao.remove(symbol, amount);

    // Clear the input fields after successful removal
    document.getElementById("currencySymbolSelect").value = "";
    document.getElementById("currencySymbolManualInput").value = "";
    document.getElementById("amount").value = "";

    // Hide any previous error message
    hideError();

    // Refresh the UI to reflect the updated holdings
    await refreshUI();

    // Hide the loading spinner
    hideLoading();
    //
    showRemoveSuccess(`Currency "${symbol}" removed successfully.`);
}

// Function to display a temporary yellow warning message when a currency is removed
function showRemoveSuccess(message) {
    // Get the success message that the currency was removed
    const removeBox = document.getElementById("removeMessage");
    const removeText = document.getElementById("removeText");

    // Set the message text
    removeText.textContent = message;
    // Show the box message
    removeBox.classList.remove("d-none");
    // Add the 'd-block' class to make the message visible
    removeBox.classList.add("d-block");

    // Hide after 3 seconds
    setTimeout(() => {
        // Hide display
        removeBox.classList.remove("d-block");
        // Fully hide
        removeBox.classList.add("d-none");
    }, 3000);
}

/**
 * Draws a pie chart using Chart.js to represent the user's holdings by USD value.
 * If no valid holdings exist, hides the chart and shows a "no data" message.
 * @async
 * @returns {Promise<void>}
 */
async function drawValueChart() {
    // Retrieve all current currency holdings from the DAO
    const holdings = dao.getHoldings();

    // If there are no holdings, hide the chart and show a "no data" message
    if (!holdings || Object.keys(holdings).length === 0) {
        document.getElementById("valueChart").style.display = "none";
        document.getElementById("valueChartLegend").innerHTML = '';
        document.getElementById("noValueChartMessage").style.display = "block";
        return;
    }

    // Ensure the chart canvas is visible
    document.getElementById("valueChart").style.display = "block";
    document.getElementById("noValueChartMessage").style.display = "none";


    // Labels for the pie chart – each label corresponds to a currency symbol (e.g., "BTC", "ETH")
    const labels = [];

    // Values for the pie chart – each value is the total USD amount of that currency
    const dataValues = [];

    // Values for the pie chart – each value is the total USD amount of that currency
    const backgroundColors = [];

    // Ensures that each currency gets a consistent and visually distinct color
    const predefinedColors = ['#e39dac', '#8fc2e4', '#dfca97', '#9de6e6', '#9966FF', '#FF9900', '#FFCD56', '#8A2BE2', '#00FFFF', '#FFD700'];

    // Loop through each currency symbol the user holds
    for (const symbol in holdings) {
        // Amount of that currency
        const amount = holdings[symbol];
        // USD exchange rate
        const rate = await service.getRate(symbol);
        // Convert to USD
        const value = amount * rate;

        // Only include currencies that have a positive dollar value
        if (value > 0) {
            // Add the currency symbol to the labels array
            labels.push(symbol);
            // Add the total USD value for that currency to the chart dataset
            dataValues.push(value);
            // Assign color
            backgroundColors.push(predefinedColors[(labels.length - 1) % predefinedColors.length]);
        }
    }

    // If no valid values found (e.g., all zero), hide chart and show message
    if (dataValues.length === 0) {
        document.getElementById("valueChart").style.display = "none";
        document.getElementById("valueChartLegend").innerHTML = '<p style="text-align: center; padding-top: 50px;">No data to show</p>';
        return;
    }

    // Prepare Chart.js data object
    const dataForChartJs = {
        labels: labels,
        datasets: [{
            data: dataValues,
            backgroundColor: backgroundColors,
            // spacing on hover
            hoverOffset: 4
        }]
    };

    // Get context for the pie chart canvas
    const ctx = document.getElementById('valueChart').getContext('2d');

    //If the chart already exists, update it with new data
    if (myChartInstance) {
        myChartInstance.data.labels = labels;
        myChartInstance.data.datasets[0].data = dataValues;
        myChartInstance.data.datasets[0].backgroundColor = backgroundColors.slice(0, labels.length);
        myChartInstance.update();
    } else {
        // If no chart exists yet, create a new one
        myChartInstance = new Chart(ctx, {
            type: 'pie',
            data: dataForChartJs,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    // Hide the title of the graph
                    title: {
                        display: false,
                        text: 'Crypto Portfolio Distribution (by Value)',
                        font: {
                            size: 16
                        }
                    },
                    // We use a custom legend instead
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            // Customize tooltip labels to show currency + formatted USD value
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed !== null) {
                                    label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(context.parsed);
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
    }

    // Create a custom legend (color-coded list of currencies)
    let legendHTML = '<ul style="list-style:none; padding:0; margin:0;">';
    for (let i = 0; i < labels.length; i++) {
        legendHTML += `
    <li style="display: flex; align-items: center; margin-bottom: 6px;">
      <span style="display: inline-block; width: 12px; height: 12px; background-color: ${backgroundColors[i]}; margin-right: 6px; border-radius: 2px;"></span>
      ${labels[i]}
    </li>`;
    }
    legendHTML += '</ul>';

    // Insert the custom legend into the page
    document.getElementById("valueChartLegend").innerHTML = legendHTML;
}

// Function to update the 'active' class on navigation buttons
function updateActiveButton(activeButtonId) {
    // Store references to all navigation buttons in an array
    const buttons = [
        // Button for table view
        document.getElementById("btnTable"),
        // Button for chart view
        document.getElementById("btnChart"),
        // Button for status view
        document.getElementById("btnStatus")
    ];

    // Loop through each button and remove the 'active' CSS class from it
    buttons.forEach(button => {
        if (button) {
            button.classList.remove("active");
        }
    });

    // Get the button element corresponding to the one that should now be active
    const activeButton = document.getElementById(activeButtonId);

    // If the button exists, apply the 'active' class to visually highlight it
    if (activeButton) {
        activeButton.classList.add("active");
    }
}

// Function that populates the holdings table with current data
async function renderTable() {
    // Get the user's current holdings as an object (e.g., { BTC: 1.5, ETH: 2.0 })
    const holdings = dao.getHoldings();
    // Get a reference to the <tbody> element where rows will be inserted
    const tbody = document.getElementById("holdingsTableBody");
    // Initialize an empty string that will accumulate the HTML for all rows
    let tableRowsHTML = "";

    // Loop over each currency symbol the user holds
    for (const symbol in holdings) {
        // Get the amount of this currency held
        const amount = holdings[symbol];
        // Get the current USD exchange rate for this currency
        const rate = await service.getRate(symbol);
        // Calculate the value in USD and format it to 2 decimal places
        const value = (amount * rate).toFixed(2);
        // Get the last updated timestamp from the DAO for this currency
        const rawTimestamp = dao.getTimestamps(symbol);
        // Format the timestamp if available; otherwise, show "N/A"
        const timestamp = rawTimestamp ? formatTimestamp(rawTimestamp) : "N/A";
        // Add one row of formatted data to the HTML string
        tableRowsHTML += `
            <tr>
                <td>${symbol}</td>
                <td>${amount}</td>
                <td>${value}$</td>
                <td>${timestamp}</td>
            </tr>
        `;
    }

    // Insert all generated rows into the table body
    tbody.innerHTML = tableRowsHTML;

    // If no currencies are held, display a placeholder row with a friendly message
    if (Object.keys(holdings).length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 20px;"> No holdings to display.<br>
      Add some cryptocurrencies!</td></tr>`;
    }
}

/**
 * Converts an ISO timestamp string into a formatted date-time string (YYYY-MM-DD HH:MM).
 * @param {string} isoString - ISO date string (e.g., "2025-07-03T15:45:00.000Z").
 * @returns {string} - Formatted string in 'YYYY-MM-DD HH:MM' format.
 */
function formatTimestamp(isoString) {
    // Convert the ISO string into a Date object
    const date = new Date(isoString);
    // Full year (e.g., 2025)
    const yyyy = date.getFullYear();
    // Month is zero-based in JS (0 = January), so add 1 and pad to 2 digits
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    // Day of the month, padded to 2 digits
    const dd = String(date.getDate()).padStart(2, '0');
    // Hours (24h format), padded to 2 digits
    const hh = String(date.getHours()).padStart(2, '0');
    // Minutes, padded to 2 digits
    const min = String(date.getMinutes()).padStart(2, '0');
    // Return the formatted string
    return `${yyyy}-${mm}-${dd} ${hh}:${min}`;
}

/**
 * Displays the loading indicator and disables form buttons to prevent user interaction.
 */
function showLoading() {
    // Show spinner
    document.getElementById("loadingIndicator").style.display = "block";
    // Disable 'Add' button
    document.getElementById("btnAdd").disabled = true;
    // Disable  'Remove' button
    document.getElementById("btnRemove").disabled = true;
}

// Function to hide the loading indicator and re-enable action buttons
function hideLoading() {
    // Hide spinner
    document.getElementById("loadingIndicator").style.display = "none";
    // Enable 'Add' button
    document.getElementById("btnAdd").disabled = false;
    // Enable 'Remove' button
    document.getElementById("btnRemove").disabled = false;
}

/**
 * Renders the portfolio summary section (status).
 * Displays total holdings, last update, and top 3 holdings by value.
 * @async
 * @returns {Promise<void>}
 */
async function renderStatus() {
    // Retrieve the user's current holdings (e.g., { BTC: 1.5, ETH: 2 })
    const holdings = dao.getHoldings();
    // Extract the currency symbols from the holdings object
    const symbols = Object.keys(holdings);
    // Calculate the total USD value of all holdings
    const total = await dao.total("USD");

    // Update summary cards
    document.getElementById("numCurrencies").textContent = symbols.length;
    document.getElementById("totalValueStatus").textContent = `$${total.toFixed(2)}`;

    // Determine the most recent timestamp among all holdings to display as 'Last Holdings Update'.
    let latestTimestamp = null;
    // Iterate through each held currency symbol.
    for (const symbol of symbols) {
        // Retrieve the last update timestamp for the current symbol.
        const ts = dao.getTimestamps(symbol);
        // If a timestamp exists for this currency, compare it to the current latest timestamp.
        if (ts) {
            // If it's the first timestamp found, or if this timestamp is more recent, update 'latestTimestamp'.
            if (!latestTimestamp || new Date(ts) > new Date(latestTimestamp)) {
                latestTimestamp = ts;
            }
        }
    }
    // Update the 'Last Holdings Update' card
    const lastUpdateElement = document.getElementById("lastUpdatedStatus");
    lastUpdateElement.textContent = latestTimestamp ? formatTimestamp(latestTimestamp) : "There is no update time";
    lastUpdateElement.classList.add("smaller-text");
}

/**
 * Refreshes the entire UI based on the current visible section.
 * Updates total, table, chart, and status components.
 * @async
 * @returns {Promise<void>}
 */
async function refreshUI() {
    // Detect which UI section is currently visible
    const tableVisible = document.getElementById("tableSection").style.display === "block";
    const chartVisible = document.getElementById("chartSection").style.display === "block";
    const statusVisible = document.getElementById("statusSection").style.display === "block";

    // Always update total
    await updateTotal();
    // Always update table
    await renderTable();

    // Only redraw charts if the chart section is visible
    if (chartVisible) {
        await drawValueChart();
    }

    // Always update the summary section
    await renderStatus();

    // Refresh the page for each button the user press
    const totalValueWrapper = document.getElementById("totalValueWrapper");
    totalValueWrapper.style.display = (statusVisible ? "none" : "block");

    // Hide loading indicator after all updates are complete
    hideLoading();

    // Restore the previously visible section to maintain user context
    if (tableVisible) showTable();
    else if (chartVisible) showChart();
    else if (statusVisible) showStatus();
}

/**
 * Displays the holdings table section and hides others.
 */
function showTable() {
    // Show the table
    document.getElementById("tableSection").style.display = "block";
    // Hide the chart
    document.getElementById("chartSection").style.display = "none";
    // Hide the status
    document.getElementById("statusSection").style.display = "none";
    // Show the total value headline
    document.getElementById("totalValueWrapper").style.display = "block";
    // Render or refresh the table content
    renderTable();
    // Highlight the active navigation button
    updateActiveButton("btnTable");
}

/**
 * Displays the chart section and hides others.
 */
function showChart() {
    // Hide the table
    document.getElementById("tableSection").style.display = "none";
    // Show the chart section
    document.getElementById("chartSection").style.display = "block";
    // Hide the status section
    document.getElementById("statusSection").style.display = "none";
    // Show the total value headline
    document.getElementById("totalValueWrapper").style.display = "block";
    // Draw the value pie chart
    drawValueChart();
    // Highlight the active navigation button
    updateActiveButton("btnChart");
}

/**
 * Displays the portfolio summary (status) section of the app and hides the table and chart sections.
 * Also hides the total value banner and highlights the active navigation button.
 */
function showStatus() {
    // Hide the table
    document.getElementById("tableSection").style.display = "none";
    // Hide the chart
    document.getElementById("chartSection").style.display = "none";
    // Show the status section
    document.getElementById("statusSection").style.display = "block";
    // Hide the total value headline from the status section
    document.getElementById("totalValueWrapper").style.display = "none";
    // Render the summary text
    renderStatus();
    // Highlight the active navigation button
    updateActiveButton("btnStatus");
}
