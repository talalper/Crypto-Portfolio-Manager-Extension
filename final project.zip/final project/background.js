/**
 * Service Worker for the Chrome Extension.
 * Overrides the default browser action behavior by opening `popup.html`
 * in a new standalone window when the extension icon is clicked.
 * This allows the extension UI to be displayed as a full-page interface
 * instead of a compact popup.
 */
chrome.action.onClicked.addListener(() => {
    chrome.windows.create({
        url: chrome.runtime.getURL("popup.html"),
        type: "popup",
        width: 1000,
        height: 800
    });
});